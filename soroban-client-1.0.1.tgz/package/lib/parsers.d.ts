import { SorobanRpc } from './soroban_rpc';
export declare function parseRawSendTransaction(r: SorobanRpc.RawSendTransactionResponse): SorobanRpc.SendTransactionResponse;
export declare function parseRawEvents(r: SorobanRpc.RawGetEventsResponse): SorobanRpc.GetEventsResponse;
export declare function parseRawLedgerEntries(raw: SorobanRpc.RawGetLedgerEntriesResponse): SorobanRpc.GetLedgerEntriesResponse;
/**
 * Converts a raw response schema into one with parsed XDR fields and a
 * simplified interface.
 *
 * @param raw   the raw response schema (parsed ones are allowed, best-effort
 *    detected, and returned untouched)
 *
 * @returns the original parameter (if already parsed), parsed otherwise
 *
 * @warning This API is only exported for testing purposes and should not be
 *          relied on or considered "stable".
 */
export declare function parseRawSimulation(sim: SorobanRpc.SimulateTransactionResponse | SorobanRpc.RawSimulateTransactionResponse): SorobanRpc.SimulateTransactionResponse;
